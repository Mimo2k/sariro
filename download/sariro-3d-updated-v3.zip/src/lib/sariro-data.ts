/**
 * SARIRO — Centralized content (derived from the SARIRO blueprint).
 * Brand: "Teaching the future. We teach thinking, not just coding."
 */

export const BRAND = {
  name: "Sariro",
  founder: "Mimo Patra",
  tagline: "Teaching the future. We teach thinking, not just coding.",
  mission:
    "We don't just teach you to write code. We teach you to think — to break problems apart, to reason about systems, and to build the future with confidence.",
  email: "contact@sariro.com",
  phone: "+1 (415) 555-0142",
  location: "San Francisco · Remote-first · Worldwide",
};

/* ---------- Email directory (5 mailboxes — @sariro.com) ----------
   Each entry maps a purpose to its inbox so the contact page can show
   them as a directory instead of a single "email us" card. */
export const EMAILS = [
  {
    id: "contact",
    address: "contact@sariro.com",
    label: "General",
    purpose: "Anything & everything. Questions about courses, partnerships, scholarships — start here.",
    icon: "Mail",
    accent: "#16A34A",
  },
  {
    id: "support",
    address: "support@sariro.com",
    label: "Support",
    purpose: "Already enrolled? Cohort access, refunds, technical issues, recordings.",
    icon: "LifeBuoy",
    accent: "#2563EB",
  },
  {
    id: "dev",
    address: "dev@sariro.com",
    label: "Development",
    purpose: "Technical & product. Bugs, feature requests, integrations, API access, open-source collabs.",
    icon: "Briefcase",
    accent: "#7C3AED",
  },
  {
    id: "hr",
    address: "hr@sariro.com",
    label: "Careers",
    purpose: "Join the team. Mentors, curriculum designers, ops — we hire from inside first.",
    icon: "Handshake",
    accent: "#F59E0B",
  },
  {
    id: "founder",
    address: "founder@sariro.com",
    label: "Founder",
    purpose: "Direct line to Mimo Patra. Partnerships, press, investor conversations, big ideas.",
    icon: "Sparkles",
    accent: "#06B6D4",
  },
] as const;

/* ---------- Sariro (the company) — narrative for the About page ----------
   Sits ABOVE the Mimo section so visitors learn the brand first. */
export const SARIRO_ABOUT = {
  eyebrow: "About Sariro",
  headline: "An education brand that refuses to teach the easy way.",
  lead:
    "Sariro is a cohort-based AI education studio founded in San Francisco. We teach thinking, not just typing — and we back it up with curriculum that ships real, working AI artifacts, not 'hello world' demos.",
  paragraphs: [
    "We started Sariro after a decade of watching smart students graduate unable to build anything real. They could pass exams. They could recite definitions. But ship a working AI feature? Freeze. The fix was not more tutorials — it was teaching thinking.",
    "Every Sariro cohort is small (30–40 students), live, mentor-led, and project-first. No pre-recorded video dumps. No copy-paste notebooks. You build, you ship, you defend your work — and you leave with a portfolio you can show an employer, a client, or a school.",
    "We have taught 5,000+ students across 65 nationalities, partnered with schools and districts on three continents, and shipped open-source tools used by thousands of developers. We are still obsessed with the same question: how do you teach AI in a way that actually lasts?",
  ],
  stats: [
    { value: 5000, suffix: "+", label: "Students taught", accent: "blue" },
    { value: 65, suffix: "+", label: "Nationalities", accent: "green" },
    { value: 200, suffix: "+", label: "Cohorts run", accent: "violet" },
    { value: 1000, suffix: "+", label: "Projects shipped", accent: "amber" },
  ] as const,
  principles: [
    {
      title: "Cohort-based, not self-paced",
      body: "Self-paced courses have a 4% completion rate. Cohorts have 87%. We pick the model that actually finishes.",
    },
    {
      title: "Mentor-led, not video-led",
      body: "Every cohort is led by a senior builder who has shipped AI to production. You learn from scars, not slides.",
    },
    {
      title: "Project-first, not theory-first",
      body: "Theory comes when you need it. Every module ends with something working — not a quiz.",
    },
    {
      title: "Open knowledge, not gatekept",
      body: "Our resources, syllabi, and many of our tools are open. Pay for the cohort and the mentor, not the content.",
    },
  ],
};

/* ---------- Team (after Mimo, on the About page) ---------- */
export const TEAM = [
  {
    name: "Mimo Patra",
    role: "Founder & Lead Educator",
    bio: "12+ years teaching. 36 published papers. 7 patents. Mimo leads the flagship AI Foundations cohort and writes most of the curriculum.",
    avatar: "M",
    accent: "#F59E0B",
    isFounder: true,
  },
  {
    name: "Dr. Lena Okafor",
    role: "Head of School Partnerships",
    bio: "Former principal turned curriculum designer. Lena runs our school partnerships and trains teachers on the Sariro method.",
    avatar: "L",
    accent: "#16A34A",
  },
  {
    name: "Marco Rossi",
    role: "Lead Mentor — LLM Applications",
    bio: "Senior PM at a fintech by day, Sariro mentor by night. Marco has shipped 4 RAG apps to production and reviews every Builder project.",
    avatar: "M",
    accent: "#2563EB",
  },
  {
    name: "Priya Nair",
    role: "Lead Mentor — Computer Vision",
    bio: "ML engineer at a stealth startup. Priya wrote our evals framework and mentors the CV and Agents cohorts.",
    avatar: "P",
    accent: "#7C3AED",
  },
  {
    name: "James Chen",
    role: "Career Mentor",
    bio: "History teacher → AI engineer. James runs our career sessions and the alumni Slack. He has reviewed 1,000+ portfolios.",
    avatar: "J",
    accent: "#06B6D4",
  },
  {
    name: "Sofia Alvarez",
    role: "Community & Mentor Program",
    bio: "Built her first neural net at 16 with Sariro. Now runs our mentor program and the student-led AI ethics club.",
    avatar: "S",
    accent: "#EC4899",
  },
] as const;

export const NAV_LINKS = [
  { id: "courses", label: "Courses" },
  { id: "tracks", label: "Tracks" },
  { id: "stats", label: "Impact" },
  { id: "events", label: "Events" },
  { id: "testimonials", label: "Voices" },
  { id: "pricing", label: "Pricing" },
];

export const TRUSTED_BY = [
  "McGraw-Hill",
  "Google Student Club",
  "Codingal",
  "Stanford Online",
  "MIT Bootcamps",
  "Khan Academy",
];

export const HERO_STATS = [
  { value: 5000, suffix: "+", label: "Students taught", accent: "blue" },
  { value: 65, suffix: "+", label: "Nationalities", accent: "green" },
  { value: 36, suffix: "", label: "Research papers", accent: "violet" },
  { value: 7, suffix: "", label: "Patents filed", accent: "amber" },
] as const;

export const TRACKS = [
  {
    id: "students",
    title: "For Students",
    tagline: "Become an AI builder, not just an AI user",
    description:
      "Cohort-based courses that take you from curious beginner to confident AI builder. Real projects, real mentorship, real outcomes — no fluff, no copy-paste tutorials.",
    icon: "GraduationCap",
    accent: "blue",
    points: [
      "Live cohorts of 30–40 students",
      "Personalized project feedback",
      "Lifetime community access",
      "Job-ready portfolio in 12 weeks",
    ],
    cta: "Browse student courses",
  },
  {
    id: "schools",
    title: "For Schools",
    tagline: "Bring AI literacy to your entire campus",
    description:
      "From single workshops to full-semester AI labs, we partner with schools to deliver curriculum that meets students where they are — and takes them far beyond.",
    icon: "School",
    accent: "green",
    points: [
      "Workshops, hackathons, full curriculum",
      "Teacher training included",
      "Aligned to CSTA & IB standards",
      "Flexible in-person or remote",
    ],
    cta: "Explore school packages",
  },
  {
    id: "professionals",
    title: "For Professionals",
    tagline: "Stay relevant in the age of AI",
    description:
      "Short, focused tracks for engineers, product managers, and leaders who need to ship AI features — without quitting their day job or wading through theory.",
    icon: "Briefcase",
    accent: "violet",
    points: [
      "Evening & weekend cohorts",
      "Industry-focused projects",
      "1:1 career strategy sessions",
      "Certificate of completion",
    ],
    cta: "See professional tracks",
  },
];

export const COURSES = [
  {
    id: "ai-foundations",
    title: "AI Foundations: Thinking in Systems",
    tagline: "Start here. Build the mental models that everything else rests on.",
    level: "Beginner",
    audience: "Students",
    durationWeeks: 8,
    modules: 6,
    price: 149,
    originalPrice: 199,
    nextCohort: "Aug 12, 2026",
    featured: true,
    accent: "blue",
    outcomes: [
      "Reason about problems like an AI engineer",
      "Read and critique AI news without hype",
      "Build 3 portfolio-ready mini projects",
    ],
  },
  {
    id: "prompt-engineering",
    title: "Prompt Engineering Mastery",
    tagline: "From 'vibes-based prompting' to engineered, reproducible prompts.",
    level: "Beginner",
    audience: "Professionals",
    durationWeeks: 4,
    modules: 4,
    price: 99,
    originalPrice: 129,
    nextCohort: "Jul 22, 2026",
    featured: true,
    accent: "violet",
    outcomes: [
      "Design prompts that ship to production",
      "Build a reusable prompt library",
      "Evaluate prompts with real metrics",
    ],
  },
  {
    id: "llm-applications",
    title: "Building LLM Applications",
    tagline: "Ship a real RAG app from scratch — embeddings, retrieval, eval.",
    level: "Intermediate",
    audience: "Students",
    durationWeeks: 12,
    modules: 9,
    price: 349,
    originalPrice: 449,
    nextCohort: "Sep 03, 2026",
    featured: true,
    accent: "green",
    outcomes: [
      "Production RAG app in your portfolio",
      "Understand vector DBs end-to-end",
      "Eval & guardrails that actually work",
    ],
  },
  {
    id: "computer-vision",
    title: "Computer Vision with PyTorch",
    tagline: "From pixels to production — train, fine-tune, and deploy CV models.",
    level: "Intermediate",
    audience: "Students",
    durationWeeks: 10,
    modules: 8,
    price: 299,
    originalPrice: 379,
    nextCohort: "Sep 17, 2026",
    featured: false,
    accent: "amber",
    outcomes: [
      "Train a custom classifier from scratch",
      "Fine-tune YOLO for real-time detection",
      "Deploy a CV endpoint to the cloud",
    ],
  },
  {
    id: "ai-ethics",
    title: "AI Ethics & Responsible Design",
    tagline: "The course every AI builder should take before shipping anything.",
    level: "All Levels",
    audience: "Professionals",
    durationWeeks: 6,
    modules: 5,
    price: 199,
    originalPrice: 249,
    nextCohort: "Aug 05, 2026",
    featured: false,
    accent: "blue",
    outcomes: [
      "Audit a model for bias and harm",
      "Write an AI acceptable-use policy",
      "Lead an ethics review at your org",
    ],
  },
  {
    id: "agents-automation",
    title: "AI Agents & Workflow Automation",
    tagline: "Build autonomous agents that actually complete real tasks.",
    level: "Advanced",
    audience: "Professionals",
    durationWeeks: 8,
    modules: 7,
    price: 399,
    originalPrice: 499,
    nextCohort: "Oct 14, 2026",
    featured: false,
    accent: "cyan",
    outcomes: [
      "Multi-agent system in your portfolio",
      "Tool-use + function-calling mastery",
      "Eval harness for agent reliability",
    ],
  },
];

export const EVENTS = [
  {
    id: "summer-cohort-2026",
    title: "Summer AI Builder Cohort",
    type: "Cohort",
    date: "Aug 12 — Oct 04, 2026",
    format: "Remote",
    location: "Online · Live",
    price: "From $149",
    accent: "blue",
    description:
      "8 weeks. 40 students. 3 portfolio projects. The flagship Sariro experience.",
  },
  {
    id: "ai-hackathon-fall",
    title: "AI for Good Hackathon",
    type: "Hackathon",
    date: "Sep 20 — Sep 22, 2026",
    format: "Hybrid",
    location: "SF + Remote",
    price: "Free",
    accent: "green",
    description:
      "48 hours. Real nonprofits. Real AI solutions. $10k in prizes across 3 tracks.",
  },
  {
    id: "prompt-jam-webinar",
    title: "Prompt Jam: Live Workshop",
    type: "Webinar",
    date: "Jul 22, 2026 · 6pm PT",
    format: "Remote",
    location: "Online · 90 min",
    price: "Free",
    accent: "violet",
    description:
      "Build a production-grade prompt library in 90 minutes. Bring your laptop.",
  },
];

export const TESTIMONIALS = [
  {
    name: "Aarav Mehta",
    role: "CS Student · IIT Bombay",
    quote:
      "Sariro is the only place that taught me WHY models work, not just how to call the API. I went from 'AI curious' to shipping a RAG app at my internship in 6 weeks.",
    avatar: "A",
    accent: "blue",
  },
  {
    name: "Dr. Lena Okafor",
    role: "Principal · Lakeside Academy",
    quote:
      "We brought Sariro in for a semester-long AI lab. The teacher training alone was worth it. Our students now lead the school's AI ethics club — they started it themselves.",
    avatar: "L",
    accent: "green",
  },
  {
    name: "Marco Rossi",
    role: "Senior PM · Fintech",
    quote:
      "I've taken 4 'AI for PMs' courses. This is the only one that respected my time. The evening cohort fit around my job and the project I shipped is now in our roadmap.",
    avatar: "M",
    accent: "violet",
  },
  {
    name: "Priya Nair",
    role: "ML Engineer · Startup",
    quote:
      "The evals module alone was worth 10x the price. I now have a framework I use every week. Mimo teaches the way I wish every senior engineer had taught me.",
    avatar: "P",
    accent: "amber",
  },
  {
    name: "James Chen",
    role: "Career Switcher",
    quote:
      "I was a history teacher. I'm now an AI engineer at a 50-person startup. Sariro didn't just teach me — it gave me the confidence to call myself a builder.",
    avatar: "J",
    accent: "cyan",
  },
  {
    name: "Sofia Alvarez",
    role: "HS Junior · Mexico City",
    quote:
      "I thought AI was for genius coders. Mimo made me realize it's for curious humans. I built my first neural net at 16 — and now I'm mentoring younger students.",
    avatar: "S",
    accent: "blue",
  },
];

export const PRICING_TIERS = [
  {
    id: "starter",
    name: "Starter",
    price: 149,
    originalPrice: 199,
    period: "per cohort",
    accent: "blue",
    tagline: "Dip your toes in. Perfect for first-time builders.",
    features: [
      "1 cohort enrollment",
      "All live sessions + recordings",
      "Community access during cohort",
      "Certificate of completion",
      "1 portfolio project reviewed",
    ],
    cta: "Start with Starter",
    popular: false,
  },
  {
    id: "builder",
    name: "Builder",
    price: 349,
    originalPrice: 449,
    period: "per cohort",
    accent: "green",
    tagline: "Go deep. Build a real, shippable AI application.",
    features: [
      "1 advanced cohort enrollment",
      "Everything in Starter, plus:",
      "1:1 mentor sessions (3x)",
      "Lifetime community access",
      "3 portfolio projects reviewed",
      "Career strategy session",
      "Priority event invites",
    ],
    cta: "Become a Builder",
    popular: true,
  },
  {
    id: "school-pro",
    name: "School Pro",
    price: null,
    originalPrice: null,
    period: "custom",
    accent: "violet",
    tagline: "Bring AI to your entire campus — we'll design it together.",
    features: [
      "Full-semester AI curriculum",
      "Teacher training (up to 10 staff)",
      "Workshops + hackathon included",
      "Custom learning portal",
      "Quarterly impact reports",
      "Dedicated success manager",
      "CSTA / IB alignment docs",
    ],
    cta: "Talk to our team",
    popular: false,
  },
];

export const MIMO = {
  name: "Mimo Patra",
  title: "Founder & Lead Educator",
  bio: "AI educator, researcher, and patent-holding inventor. Mimo has taught 5,000+ students across 65 nationalities, published 36 research papers, and filed 7 patents — all while staying obsessed with one question: how do you teach AI in a way that lasts?",
  numbers: [
    { value: "12+", label: "Years teaching" },
    { value: "5K+", label: "Students mentored" },
    { value: "36", label: "Papers published" },
    { value: "7", label: "Patents filed" },
  ],
  principles: [
    {
      title: "Thinking over typing",
      body: "Anyone can copy a tutorial. We teach you to think — to break problems apart, to ask the right questions, to reason about systems. The typing comes naturally after.",
    },
    {
      title: "Build real things",
      body: "Every Sariro course ends with something you can show an employer, a client, or a school. Not a 'hello world' — a real, working, evaluated AI artifact.",
    },
    {
      title: "Accessible by design",
      body: "AI education shouldn't be gatekept by jargon. We teach in plain language. An 8-year-old and a grandpa should both be able to follow along.",
    },
    {
      title: "Community, not customers",
      body: "Once you're in, you're in. Lifetime community access, mentorship opportunities, and a network that shows up when you ship — and when you stumble.",
    },
  ],
};

/* Summer 2026 launch pricing — early-bird discount window
   (active until Aug 12, 2026). `originalPrice` is the standard
   cohort price; `price` is the discounted price shown live. */
export const DISCOUNT_LABEL = 'Summer launch — 25% off';
export const DISCOUNT_DEADLINE = 'Aug 12, 2026';

/** Returns the integer discount percent for a tier/course, or 0 if no discount. */
export function discountPercent(price: number | null, original?: number | null): number {
  if (!price || !original || original <= price) return 0;
  return Math.round(((original - price) / original) * 100);
}

export const FOOTER_LINKS = {
  Learn: ["Courses", "Tracks", "Events", "Resources", "YouTube"],
  Company: ["About Mimo", "Blog", "Careers", "Press kit"],
  Support: ["Contact", "FAQ", "Privacy Policy", "Refund Policy"],
};
